library(testthat)
library(sensorsUtils)

test_check("sensorsUtils")

